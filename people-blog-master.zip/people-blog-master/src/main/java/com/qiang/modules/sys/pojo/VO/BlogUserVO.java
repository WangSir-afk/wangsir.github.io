package com.qiang.modules.sys.pojo.VO;

import com.qiang.modules.sys.pojo.Comment;

/**
 * @Author: qiang
 * @ProjectName: adminsystem
 * @Package: com.qiang.modules.sys.pojo.VO
 * @Description: 评论相关信息
 * @Date: 2019/7/22 0022 16:38
 **/
public class BlogUserVO extends Comment {

}
