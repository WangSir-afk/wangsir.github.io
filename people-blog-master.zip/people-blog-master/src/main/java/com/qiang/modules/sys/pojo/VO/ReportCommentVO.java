package com.qiang.modules.sys.pojo.VO;

import com.qiang.modules.sys.pojo.ReportComment;

/**
 * @Author: qiang
 * @ProjectName: adminsystem
 * @Package: com.qiang.modules.sys.pojo.VO
 * @Description:
 * @Date: 2019/7/30 0030 19:29
 **/
public class ReportCommentVO extends ReportComment {

    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
