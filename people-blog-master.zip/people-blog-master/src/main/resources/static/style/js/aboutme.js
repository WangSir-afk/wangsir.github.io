$(function () {
    scrollTo(0, 0);//回到顶部
})